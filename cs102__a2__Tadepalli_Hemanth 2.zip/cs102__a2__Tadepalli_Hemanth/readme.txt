For the Sortedlinkedlist.java file I had to add the delete method to include the deletion. 




I used an Arraylist becuase it is faster to index through while a linked lists would reult in a latency.
Another reason why I chose ArrayList was becuase it doesn't give false assumptions about the elements inside the 
data structure that have any correlations between the order they were added. 