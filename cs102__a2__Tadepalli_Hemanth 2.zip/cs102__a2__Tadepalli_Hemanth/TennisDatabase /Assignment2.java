// Hemanth Tadepalli
// CS-102, Spring 2020
// Assignment 2


import java.lang.String;
import java.util.*;
import java.io.*;
import java.util.Scanner;

public class Assignment2 {
    public static void main(String[] args) {
        Scanner user_sc = new Scanner(System.in);
        String filename = "/Users/hemanthtadepalli/Desktop/cs102__a2__Tadepalli_Hemanth/example_input_file.txt";
        System.out.println(filename);

        File file = new File(filename);
        Scanner file_sc = null;
        try {
            file_sc = new Scanner(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        TennisDatabase data = new TennisDatabase();
        try {
            data.loadFromFile(filename);
        } catch (Exception e) {
            e.printStackTrace();
        }

        String choice = " 0 ";
        while (!choice.equals("6")) {
            System.out.println("\n\nCS-102 Tennis Manager - Available commands:");
            System.out.println("1 --> Print all tennis players");
            System.out.println("2 --> Print all tennis matches of a player");
            System.out.println("3 --> Print all tennis matches");
            System.out.println("4 --> Insert a new tennis player");
            System.out.println("5 --> Insert a new tennis match");
            System.out.println("6 --> Exit");
            System.out.println("7 --> Print a player");
            System.out.println("8 --> Delete a Player");
            System.out.println("9 --> Reset the database");
            System.out.println("10 --> Import from File");
            System.out.println("11 --> Export to File");
            System.out.print("Your choice? ");
            choice = user_sc.nextLine();

            System.out.println(choice);
            TennisMatch[] ms;
            try {
                switch (choice) {
                    case "1": //Print all players
                       
                        TennisPlayerContainerNode tree = data.getPlayerContainer().getRoot();

                        TennisPlayerContainerIterator iterator = new TennisPlayerContainerIterator(tree, 1);
                        while (iterator.hasNext()) {
                            TennisPlayer player = iterator.next();
                            int wins = data.getWinsOfPlayer(player.getId());
                            System.out.println(player.getId() + ": " + player.getFirstName() + " " + player.getLastName() + " , " +
                                    player.getBirthYear() + " , " + player.getCountry() + " , " + wins + " / " +
                                    (data.getMatchesOfPlayer(player.getId()).length - wins));
                        }
                        break;
                    case "2":
                        System.out.print("Enter Player Id: ");
                        String id = user_sc.nextLine();

                        System.out.println(id);
                        ms = data.getMatchesOfPlayer(id);
                        for (int i = 0; i < ms.length; i++) {
                            System.out.println(ms[i].getDateYear() + "/ " + ms[i].getDateMonth() + " / " + ms[i].getDateDay() + " , " +

                                    data.getPlayer(ms[i].getIdPlayer1()).getFirstName().substring(0, 1) + " . " + data.getPlayer(ms[i].getIdPlayer1()).getLastName() + " - " +
                                    data.getPlayer(ms[i].getIdPlayer2()).getFirstName().substring(0, 1) + " . " + data.getPlayer(ms[i].getIdPlayer2()).getLastName() + ", " +
                                    ms[i].getTournament() + " , " + ms[i].getMatchScore());

                        }
                        break;
                    case "3":

                        ms = data.getAllMatches();
                        for (int i = 0; i < ms.length; i++) {
                            System.out.println(ms[i].getDateYear() + "/ " + ms[i].getDateMonth() + " / " + ms[i].getDateDay() + " , " +

                                    data.getPlayer(ms[i].getIdPlayer1()).getFirstName().substring(0, 1) + " . " + data.getPlayer(ms[i].getIdPlayer1()).getLastName() + " - " +
                                    data.getPlayer(ms[i].getIdPlayer2()).getFirstName().substring(0, 1) + " . " + data.getPlayer(ms[i].getIdPlayer2()).getLastName() + ", " +
                                    ms[i].getTournament() + " , " + ms[i].getMatchScore());
                        }
                        break;
                    case "4":
                        System.out.print("Enter Player Id: ");
                
                        String pid = user_sc.nextLine();
                        System.out.print("Enter Player First Name: ");
                        String firstName = user_sc.nextLine();
                        System.out.print("Enter Player Last Name: ");
                        String lastName = user_sc.nextLine();
                        System.out.print("Enter Player Birth Year: ");
                        String year = user_sc.nextLine();
                        System.out.print("Enter Player Country: ");
                        String country = user_sc.nextLine();
                        data.insertPlayer(pid, firstName, lastName, Integer.parseInt(year), country);
                        break;
                    case "5":
                        System.out.print("Enter Player Id1: ");
                        String pid1 = user_sc.nextLine();
                        System.out.print("Enter Player Id2: ");
                        String pid2 = user_sc.nextLine();
                        System.out.print("Enter Match Year: ");
                        String mYear = user_sc.nextLine();
                        System.out.print("Enter Match Month: ");
                        String mMonth = user_sc.nextLine();
                        System.out.print("Enter Match Day: ");
                        String mDay = user_sc.nextLine();
                        System.out.print("Enter Tournament: ");
                        String tournament = user_sc.nextLine();
                        System.out.print("Enter Scores: ");
                        String scores = user_sc.nextLine();
                        data.insertMatch(pid1, pid2, Integer.parseInt(mYear), Integer.parseInt(mMonth), Integer.parseInt(mDay), tournament, scores);
                        break;
                    case "6":
                        System.out.println("exiting now\n");
                        break;
                    // Print a player
                    case "7":
                        System.out.println("print a player \n");
                        System.out.print("Enter Player Id: ");
                        pid = user_sc.nextLine();
                        TennisPlayer p = data.getPlayer(pid);
                        System.out.println(p.getId() + ": " + p.getFirstName() + " " + p.getLastName() + " , " +
                                p.getBirthYear() + " , " + p.getCountry() + " , " + data.getWinsOfPlayer(p.getId()) + " / " +
                                (data.getMatchesOfPlayer(p.getId()).length - data.getWinsOfPlayer(p.getId())));
                        break;
                    //Delete a Player
                    case "8":
                        System.out.println("delete a player \n");
                        System.out.print("Enter Player Id: ");
                        pid = user_sc.nextLine();
                        data.deletePlayer(pid);
                        break;
                    //Reset the database
                    case "9":
                        System.out.println("reset the database \n");
                        data.reset();
                        break;
                    //Import from file
                   case "10":
                      System.out.println("import from file \n");
                      System.out.println("File name: ");
                      filename = user_sc.nextLine();
                      data.loadFromFile(filename);
                      break;
                    //Export to file
                   case "11":
                      System.out.println("export to file \n");
                      System.out.println("File name: ");
                      filename = user_sc.nextLine();
                      data.saveToFile(filename);
                      break;
                   default:
                      System.out.println("Invalid Choice!\n");
                      break;
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }
}



