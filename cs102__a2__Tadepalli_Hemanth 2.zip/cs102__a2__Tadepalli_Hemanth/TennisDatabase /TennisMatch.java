// Hemanth Tadepalli
// CS-102, Spring 2020
// Assignment 2


// Custom (checked) exception for the TennisDatabase package, representing critical runtime errors (that must be handled).
public class TennisMatch implements TennisMatchInterface {

   
   private String idPlayer1;
   private String idPlayer2;
   private int dateYear;
   private int dateMonth;
   private int dateDay;
   private String tournament;
   private String matchScore;
   private int winner;
  
   //Creating the constructors 
   public TennisMatch()
   {
	      this.idPlayer1 = null;
	      this.idPlayer2 = null;
	      this.dateYear = 0;
	      this.dateMonth = 0;
         this.dateDay = 0;
	      this.tournament = null;
	      this.matchScore = null;
	      this.winner = 0;
   }
   
   
   //constructor with parameters
   public TennisMatch(String idPlayer1, String idPlayer2, int dateYear, int dateMonth, int dateDay, String tournament, String matchScore  )
   {
         this.idPlayer1 = idPlayer1;
	      this.idPlayer2 = idPlayer2;
	      this.dateYear = dateYear ;
	      this.dateMonth = dateMonth;
         this.dateDay = dateDay;
	      this.tournament = tournament;
	      this.matchScore = matchScore ;
         if (findWinner (matchScore) > 0){
            this.winner = 1;
         }
         else {
               
            this.winner = 2;
         }
	         
         
   }



   public String getIdPlayer1(){
      return this.idPlayer1;
   }
   public String getIdPlayer2(){
      return this.idPlayer2;
   }
   public int getDateYear(){
      return this.dateYear;
   }     
   public int getDateMonth(){
      return this.dateMonth;
   }
   public int getDateDay(){
      return this.dateDay;
   }
   public String getTournament(){
      return this.tournament;
   }
   public String getMatchScore(){
      return this.matchScore;
   }
   public int getWinner(){
      return this.winner;
   } 
   
   
   
    public int compareTo (TennisMatch other) {
    
    if (this.dateYear < other.dateYear){
      return -1;
     
    }
    
    else if(this.dateYear > other.dateYear){
      return 1;
    }
    
    else if( this.dateMonth > other.dateMonth){
      return 1;
    }
    else if( this.dateMonth < other.dateMonth){
      return -1;
    }
     
    else if( this.dateDay > other.dateDay){
      return 1;
    }
    else if( this.dateDay < other.dateDay){
       return -1;
    }

    else {
     
      return -1;
    }
    
           
   }


   public int findWinner(String scores){
      if (scores.length() == 3){
         if  (Integer.parseInt(scores.substring(0,1))  <  Integer.parseInt(scores.substring(2,3))) {
      
            return -1;   
      
         }
      
         else {
      
            return 1;
         }
     }
     
      else {
   
         
      
         String set = scores.substring(0,3);
         
          return findWinner(set) + findWinner(scores.substring(4));  
   
   
         
      }
  
  }
  
}
   
      