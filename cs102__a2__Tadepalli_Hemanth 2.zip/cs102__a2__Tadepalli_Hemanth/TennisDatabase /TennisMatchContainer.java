// Hemanth Tadepalli
// CS-102, Spring 2020
// Assignment 2




import java.io.PrintStream;
import java.util.*;
// Custom (checked) exception for the TennisDatabase package, representing critical runtime errors (that must be handled).
public class TennisMatchContainer extends ArrayList<TennisMatch> implements TennisMatchContainerInterface {

   
   // Desc.: Returns the number of matches in this container.
   // Output: The number of matches in this container as an integer.
   
   public int getNumMatches(){
      return this.size();
   
   }
   
   // Desc.: Returns an iterator object ready to be used to iterate this container.
   // Output: The iterator object configured for this container.
   
   public Iterator<TennisMatch> iterator(){
      return this.listIterator();
   }

   
    // Desc.: Insert a tennis match into this container.
   // Input: A tennis match.
   // Output: Throws a checked (critical) exception if the container is full.
   
   public void insertMatch(TennisMatch m) throws TennisDatabaseException{
      this.add (m);
      Collections.sort(this);
      Collections.reverse(this);
   }
   
   // Desc.: Returns all matches in the database arranged in the output array (sorted by date, most recent first).
   // Output: Throws an exception if there are no matches in this container.
   
   public TennisMatch[] getAllMatches() throws TennisDatabaseRuntimeException{
      TennisMatch[] matches = new TennisMatch[this.size()];
      for(int i = 0; i<this.size(); i++){
      
         matches[i]= this.get(i);
      }
      return matches;
   }
   
   // Desc.: Returns all matches of input player (id) arranged in the output array (sorted by date, most recent first).
   // Input: The id of the tennis player.
   // Output: Throws an unchecked (non-critical) exception if there are no tennis matches in the list.
   
   public TennisMatch[] getMatchesOfPlayer( String playerId ) throws TennisDatabaseRuntimeException{
      TennisMatch[] matches = new TennisMatch[this.size()];
      for(int i = 0; i<this.size(); i++){
         if (playerId.equals(this.get(i).getIdPlayer1()))
         {
            matches[i]= this.get(i);
         }
         
         if (playerId.equals(this.get(i).getIdPlayer2()))
         
         {
         
            matches[i]= this.get(i);
         }

      }
      
      return matches;
      
   }

    // Desc.: Delete all matches of a player by id (if found).
   // Output: Throws an unchecked (non-critical) exception if there is no match with that input id.
   
   public void deleteMatchesOfPlayer( String playerId ) throws TennisDatabaseRuntimeException{
         
     for(int i = 0; i<this.size(); i++){
         
        if(this.get(i).getIdPlayer1().equals(playerId) || this.get(i).getIdPlayer2().equals(playerId)){
           this.remove(i);
           i--;
         

        }

      }
   }

   public void export(PrintStream ps) {
      for (TennisMatch match : getAllMatches()) {
         int month = match.getDateMonth();
         int day = match.getDateDay();
         ps.println("MATCH/" + match.getIdPlayer1() + "/" + match.getIdPlayer2() + "/" +
                 match.getDateYear() + (month < 10 ? "0" + month : month) + (day < 10 ? "0" + day : day) + "/" +
                 match.getTournament() + "/" + match.getMatchScore());
      }
   }
}
