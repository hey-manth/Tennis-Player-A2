// Hemanth Tadepalli
// CS-102, Spring 2020
// Assignment 2


public class TennisPlayerQueue implements TennisPlayerQueueInterface {
   private int capacity = 10;
   private TennisPlayer[] q;
   private int front;
   private int rear;

   public TennisPlayerQueue() {
      q = new TennisPlayer[capacity];
   }

   // Desc.: Check if the queue is empty.
   // Output: True or false.
   public boolean isEmpty() {
      return front == rear;
   }
   
   

   // Desc.: Insert a tennis player at the back of this queue.
   // Input: A tennis player.
   // Output: Throws a checked (critical) exception if the insertion fails.

   public void enqueue(TennisPlayer p) throws TennisDatabaseException {
      if (size() == capacity - 1) { // q is full
         resize();
      }
      q[rear++] = p;
      if (rear == capacity) {
         rear = 0;
      }
   }

   private void resize() {
      int oldSize = size();
      capacity *= 2;
      TennisPlayer[] newQ = new TennisPlayer[capacity];
      for (int i = 0; i < oldSize; i++) {
         newQ[i] = q[front++];
         if (front == oldSize + 1) {
            front = 0;
         }
      }
      q = newQ;
      front = 0;
      rear = oldSize;
   }
   
   

    // Desc.: Extract (return and remove) a tennis player from the front of this queue.
   // Output: Throws a checked (critical) exception if the extraction fails.

   public TennisPlayer dequeue() throws TennisDatabaseException {
      if (isEmpty()) {
         throw new TennisDatabaseException("Extraction failed");
      }
      TennisPlayer p = q[front++];
      if (front == capacity) {
         front = 0;
      }
      return p;
   }
   
   

  // Desc.: Return (without removing) the tennis player at the front of this queue.
   // Output: Throws a checked (critical) exception if the queue is empty.
   public TennisPlayer peek() throws TennisDatabaseException {
      if (isEmpty()) {
         throw new TennisDatabaseException("Extraction failed");
      }
      return q[front];
   }

   public int size() {
      return (capacity - front + rear) % capacity;
   }
}

