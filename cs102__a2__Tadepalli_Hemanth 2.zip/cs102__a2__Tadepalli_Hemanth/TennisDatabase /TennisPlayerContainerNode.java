// Hemanth Tadepalli
// CS-102, Spring 2020
// Assignment 2




// Custom (checked) exception for the TennisDatabase package, representing critical runtime errors (that must be handled).
public class TennisPlayerContainerNode implements TennisPlayerContainerNodeInterface {
   private SortedLinkedList<TennisMatch> matchList;
   private TennisPlayer player;
   private TennisPlayerContainerNode left,right;
   
   
   public TennisPlayerContainerNode (TennisPlayer player) {
      this.player = player;
      this.left = null;
      this.right = null;
      this.matchList = new SortedLinkedList<TennisMatch>();
   } 
    
    
    // Accessors (getters).
   public TennisPlayer getPlayer(){
      return player;
   }
   public SortedLinkedList<TennisMatch> getMatchList(){
      return matchList;
   }
   public TennisPlayerContainerNode getLeftChild(){
      return left;
   }
   public TennisPlayerContainerNode getRightChild(){
      return right;
   }   
  
   // Modifiers (setters).
   
   
   public void setPlayer( TennisPlayer p ){
      this.player=p;
   }
   public void setMatchList( SortedLinkedList<TennisMatch> m1 ){
       this.matchList=m1;
   }
   public void setLeftChild( TennisPlayerContainerNode lc ){
        this.left = lc;
   }
   public void setRightChild( TennisPlayerContainerNode rc ){
         this.right = rc;
   }
   
     
   
   
   // Desc.: Insert a TennisMatch object (reference) into this node.
   // Input: A TennisMatch object (reference).
   // Output: Throws a checked (critical) exception if match cannot be inserted in this player list.
   public void insertMatch(TennisMatch m) throws TennisDatabaseException {
      try {
         this.matchList.insert(m);
      } catch (Exception e) {
         throw new TennisDatabaseException("Linked list insertion of a match failed!");
      }
   }
   
   
   // Desc.: Returns all matches of this player arranged in the output array (sorted by date, most recent first).
   // Output: Throws an unchecked (non-critical) exception if there are no matches for this player.
   public TennisMatch[] getMatches() throws TennisDatabaseRuntimeException{
      TennisMatch[] matches = new TennisMatch[this.matchList.size()];
      for(int i = 0; i<this.matchList.size(); i++){
         matches[i]= this.matchList.get(i);
      }
      return matches;
   }
  
  
   // Desc.: Deletes all matches of input player (id) from this node.
   // Input: The id of the tennis player.
   // Output: Throws an unchecked (non-critical) exception if no matches are deleted.
   public void deleteMatchesOfPlayer( String playerId ) throws TennisDatabaseRuntimeException{
   
   
     for(int i = 0; i<this.matchList.size(); i++){
        if(this.matchList.get(i).getIdPlayer1().equals(playerId) || this.matchList.get(i).getIdPlayer2().equals(playerId)){
           this.matchList.delete(i);
           i--;
        }        
     }

   }
      
  


   


      
}
