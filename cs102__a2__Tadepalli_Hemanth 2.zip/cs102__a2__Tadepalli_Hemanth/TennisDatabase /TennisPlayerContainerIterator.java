// Hemanth Tadepalli
// CS-102, Spring 2020
// Assignment 2


import java.util.*;


// Custom (checked) exception for the TennisDatabase package, representing critical runtime errors (that must be handled).
public class TennisPlayerContainerIterator implements Iterator<TennisPlayer> {
   private TennisPlayerQueue q = new TennisPlayerQueue();

   public TennisPlayerContainerIterator(TennisPlayerContainerNode tree, int choice) throws TennisDatabaseException {
         switch(choice){
         //cases
            case 1: //inorder traversal Left, Root, Right
               inorder(tree);
               break;
               
            case 2: //Reverse Inorder traversal Right, Root, Left
               reverseInorder(tree);
               break;
               
            case 3: //Preorder .... Root,left,right
               preorder(tree);
               break;

            case 4: // postorder....lEFT,RIGHT,ROOT
               postorder(tree);
               break;
               
            default: 
               break;
         }
   }


   private void postorder(TennisPlayerContainerNode tree) throws TennisDatabaseException {
      if (tree == null) {
         return;
      }

      postorder(tree.getLeftChild());
      postorder(tree.getRightChild());
      this.q.enqueue(tree.getPlayer());
   }

   private void preorder(TennisPlayerContainerNode tree) throws TennisDatabaseException {
      if (tree == null) {
         return;
      }

      this.q.enqueue(tree.getPlayer());
      preorder(tree.getLeftChild());
      preorder(tree.getRightChild());
   }

   private void reverseInorder(TennisPlayerContainerNode tree) throws TennisDatabaseException {
      // base case
      if (tree == null) {
         return;
      }

      // recursive case
      reverseInorder(tree.getRightChild());
      this.q.enqueue(tree.getPlayer());
      reverseInorder (tree.getLeftChild());
   }

   private void inorder(TennisPlayerContainerNode tree) throws TennisDatabaseException {
      // base case
      if (tree == null) {
         return;
      }

      // recursive case
      inorder (tree.getLeftChild());
      this.q.enqueue(tree.getPlayer());
      inorder(tree.getRightChild());
   }

   public TennisPlayer next() {
      try {
         return this.q.dequeue();
      } catch (TennisDatabaseException e) {
         System.out.println(e.getMessage());
         return null;
      }
   }
   
   public boolean hasNext(){
      return !this.q.isEmpty();
   }

}
