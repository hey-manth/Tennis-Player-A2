// Hemanth Tadepalli
// CS-102, Spring 2020
// Assignment 2


import java.io.PrintStream;

// Custom (checked) exception for the TennisDatabase package, representing critical runtime errors (that must be handled).
public class TennisPlayerContainer implements TennisPlayerContainerInterface {
   private TennisPlayerContainerNode root;
   private int num; 
   
   public TennisPlayerContainer(){
      this.root = null;
      this.num = 0;
   }

    public TennisPlayerContainerNode getRoot() {
        return root;
    }

    // Desc.: Returns the number of players in this container.
 // Output: The number of players in this container as an integer.
   public int getNumPlayers(){
      return num;
   }
   
   
   // Desc.: Returns an iterator object ready to be used to iterate this container.
   // Output: The iterator object configured for this container.
   public TennisPlayerContainerIterator iterator(int choice) throws TennisDatabaseException {
      return new TennisPlayerContainerIterator(this.root,choice);
   }
   
   public TennisPlayerContainerIterator iterator() throws TennisDatabaseException {
      return iterator(1);
   }
   
   
 // Desc.: Search for a player in this container by input id, and returns a copy of that player (if found).
   // Output: Throws an unchecked (non-critical) exception if there is no player with that input id.
 public TennisPlayer getPlayer(String id) throws TennisDatabaseRuntimeException, TennisDatabaseException {
     TennisPlayerContainerIterator iter = iterator();
     while (iter.hasNext()) {
         TennisPlayer p = iter.next();
         if (id.equals(p.getId())) {
             return p;
         }
     }
     throw new TennisDatabaseRuntimeException(id + " not found");
 }


   // Desc.: Insert a tennis player into this container.
   // Input: A tennis player.
   // Output: Throws a checked (critical) exception if player id is already in this container.
   //         Throws a checked (critical) exception if the container is full.
   public void insertPlayer(TennisPlayer p) throws TennisDatabaseException {
       TennisPlayerContainerNode newPlayer = new TennisPlayerContainerNode(p);
       if (this.num == 0) {
           this.root = newPlayer;
       }
       else {
         this.root = recursiveInsert(newPlayer, this.root);
       }
       this.num++;
   }
    
   private TennisPlayerContainerNode recursiveInsert(TennisPlayerContainerNode p, TennisPlayerContainerNode node) throws TennisDatabaseException {
      if (node == null) {
          return p;
      }

      int cmp = p.getPlayer().getId().compareTo(node.getPlayer().getId());
      if (cmp < 0) {
          TennisPlayerContainerNode left = recursiveInsert(p, node.getLeftChild());
          node.setLeftChild(left);
          return node;
      }
      else if (cmp > 0) {
          TennisPlayerContainerNode right = recursiveInsert(p, node.getRightChild());
          node.setRightChild(right);
          return node;
      }
      else {
          throw new TennisDatabaseException("Cannot insert because id's are identical");
      }
    }

   // Desc.: Search for a player in this container by id, and delete it with all his matches (if found).
   // Output: Throws an unchecked (non-critical) exception if there is no player with that input id.
   public void deletePlayer( String playerId ) throws TennisDatabaseRuntimeException{
        this.root = recursiveDelete(this.root, playerId);
        this.deleteMatchesOfPlayer(playerId);
   }

    private TennisPlayerContainerNode recursiveDelete(TennisPlayerContainerNode root, String playerId) {
       if (root == null) {
           throw new TennisDatabaseRuntimeException(playerId + " not found");
       }

       int cmp = playerId.compareTo(root.getPlayer().getId());
       if (cmp == 0) {
           if (root.getLeftChild() == null && root.getRightChild() == null) {
               return null;
           }
           else if (root.getLeftChild() == null) {
               return root.getRightChild();
           }
           else if (root.getRightChild() == null) {
               return root.getLeftChild();
           }
           else {
           
           
               // find the left most node of the root's right child
               TennisPlayerContainerNode leftMostNode = recursiveFindLeftMostNode(root.getRightChild());

               // copy data in leftMostNode to root
               root.setPlayer(leftMostNode.getPlayer());
               root.setMatchList(leftMostNode.getMatchList());

               return root;
           }
       }
       else if (cmp < 0) {
             root.setLeftChild(recursiveDelete(root.getLeftChild(), playerId));
             
             return root;
       }
       else { // cmp > 0
           root.setRightChild(recursiveDelete(root.getRightChild(), playerId));
           
           return root;
       }
    }

    public TennisPlayerContainerNode recursiveFindLeftMostNode(TennisPlayerContainerNode root) {
       if (root.getLeftChild() == null) {
           return root;
       }
       else {
           return recursiveFindLeftMostNode(root.getLeftChild());
       }
    }

    public TennisPlayerContainerNode search(String id) {
       return recursiveSearch(root, id);
   }

    private TennisPlayerContainerNode recursiveSearch(TennisPlayerContainerNode root, String id) {
        if (root == null) {
            throw new TennisDatabaseRuntimeException(id + " not found");
        }

        int cmp = id.compareTo(root.getPlayer().getId());
        if (cmp == 0) {
            return root;
        }
        else if (cmp < 0) {
            return recursiveSearch(root.getLeftChild(), id);
        }
        else {
            return recursiveSearch(root.getRightChild(), id);
        }
    }


    // Desc.: Insert a tennis match into the lists of both tennis players of the input match.
   // Input: A tennis match.
   // Output: Throws a checked (critical) exception if the insertion is not fully successful.
   public void insertMatch(TennisMatch m) throws Exception {
       TennisPlayerContainerNode player1 = search(m.getIdPlayer1());
       player1.getMatchList().insert(m);

       TennisPlayerContainerNode player2 = search(m.getIdPlayer2());
       player2.getMatchList().insert(m);
   }

   
   
   // Desc.: Returns all players in the database arranged in the output array (sorted by id, alphabetically).
   // Output: Throws an unchecked (non-critical) exception if there are no players in this container.
   
   public TennisPlayer[] getAllPlayers() throws TennisDatabaseRuntimeException{
   
   
//   TennisPlayerContainerNode tempHead = this.head;
//   TennisPlayer[] players = new TennisPlayer[this.num];
//      for(int i = 0; i<this.num; i++){
//
//         players[i]= tempHead.getPlayer();
//         //tempHead = tempHead.getNext();
//      }
//      return players;

       return null; 
   }

   
   // Desc.: Returns copies (deep copies) of all matches of input player (id) arranged in the output array (sorted by date, most recent first).
   // Input: The id of a player.
   // Output: Throws a checked (critical) exception if the player (id) does not exists.
   //         Throws an unchecked (non-critical) exception if there are no matches (but the player id exists).
   public TennisMatch[] getMatchesOfPlayer(String playerId) throws TennisDatabaseException, TennisDatabaseRuntimeException {
       TennisPlayerContainerNode node = search(playerId);
       return node.getMatches();
   }
   
    // Desc.: Deletes all matches of input player (id) from this container.
   // Input: The id of the tennis player.
   // Output: Throws an unchecked (non-critical) exception if no matches are deleted.
   public void deleteMatchesOfPlayer( String playerId ) throws TennisDatabaseRuntimeException{
   
      recurseDeleteM( playerId, this.root);
   
   }
   
   
   private void recurseDeleteM ( String playerId, TennisPlayerContainerNode root){
      if( root!=null){
    
         root.deleteMatchesOfPlayer( playerId );
         recurseDeleteM( playerId, root.getLeftChild());
         recurseDeleteM( playerId, root.getRightChild());
      }
      
    } 
    
    
    public void export(PrintStream ps) {
       recursiveExport(root, ps);
    }

    private void recursiveExport(TennisPlayerContainerNode root, PrintStream ps) {
        if (root == null) {
            return;
        }

        // export root...
        ps.println("PLAYER/" + root.getPlayer().getId() + "/" + root.getPlayer().getFirstName() + "/" +
                root.getPlayer().getLastName() + "/" + root.getPlayer().getBirthYear() + "/" + root.getPlayer().getCountry());
        recursiveExport(root.getLeftChild(), ps);
        recursiveExport(root.getRightChild(), ps);
    }
}


  
   
   
   
   
   
   
   
   
   